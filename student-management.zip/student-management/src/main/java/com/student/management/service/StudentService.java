package com.student.management.service;


import com.student.management.dto.StudentCreateRequestDto;
import com.student.management.dto.StudentCreateResponseDto;
import com.student.management.entity.StudentEntity;
import com.student.management.exception.ErrorDto;
import com.student.management.exception.StudentCreationException;
import com.student.management.repositry.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;


@Service
public class StudentService {
    private static  final Logger LOGGER = LoggerFactory.getLogger(StudentService.class);;
    @Autowired
    private StudentRepository studentRepository;

    @Transactional
    public StudentCreateResponseDto createStudent(StudentCreateRequestDto studentCreateRequestDto) {
        StudentCreateResponseDto studentCreateResponseDto = new StudentCreateResponseDto();
        try {

            StudentEntity studentEntity = new StudentEntity();
            BeanUtils.copyProperties(studentCreateRequestDto, studentEntity);
            studentEntity = studentRepository.save(studentEntity);
            studentCreateResponseDto.setStudentData(studentEntity);
        }
        catch(Exception ex){
            ErrorDto errorDto = new ErrorDto("Internal error occured while creating student");
            List<ErrorDto> errorDtoList = new ArrayList<>();
            errorDtoList.add(errorDto);
            studentCreateResponseDto.setErrors(errorDtoList);
            LOGGER.error("Exception occurred while creating student {}", ex.getMessage());
            throw  new StudentCreationException(errorDto);

        }
        return studentCreateResponseDto;
    }
}
