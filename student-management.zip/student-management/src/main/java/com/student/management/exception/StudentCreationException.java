package com.student.management.exception;

public class StudentCreationException extends  RuntimeException{
    private ErrorDto errorDto;

    public StudentCreationException(ErrorDto errorDto){
        super(errorDto.getErrorMessage());
        this.errorDto = errorDto;
    }

    public ErrorDto getErrorDto() {
        return errorDto;
    }
}
