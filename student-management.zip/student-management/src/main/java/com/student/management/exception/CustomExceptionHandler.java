package com.student.management.exception;

import com.student.management.dto.StudentCreateResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestControllerAdvice
public class CustomExceptionHandler  {
    @ExceptionHandler(StudentCreationException.class)
    public ResponseEntity<StudentCreateResponseDto> handleStudentCreationException(StudentCreationException ex) {
        StudentCreateResponseDto studentCreateResponseDto = new StudentCreateResponseDto();
        List<ErrorDto> errors = new ArrayList<>();
        errors.add(ex.getErrorDto());
        studentCreateResponseDto.setErrors(errors);
        return new ResponseEntity(studentCreateResponseDto, HttpStatus.INTERNAL_SERVER_ERROR);
    }



   @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<StudentCreateResponseDto> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
        StudentCreateResponseDto studentCreateResponseDto = new StudentCreateResponseDto();
        studentCreateResponseDto.setErrors(ex.getBindingResult().getAllErrors().stream().map( error->  new ErrorDto( error.getDefaultMessage()) ).
                collect(Collectors.toList()));
        return new ResponseEntity(studentCreateResponseDto, HttpStatus.BAD_REQUEST);
    }
}
