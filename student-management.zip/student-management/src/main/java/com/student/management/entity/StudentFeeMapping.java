package com.student.management.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class StudentFeeMapping {
    @Id
    @GeneratedValue
    private long id;

    private long studentId;

    private String reference;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }
}
