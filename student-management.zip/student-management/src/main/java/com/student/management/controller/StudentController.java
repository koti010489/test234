package com.student.management.controller;

import com.student.management.dto.StudentCreateRequestDto;
import com.student.management.dto.StudentCreateResponseDto;
import com.student.management.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class StudentController {
    @Autowired
    private StudentService studentService;

    @PostMapping( "/api/v1/students")
    public ResponseEntity<StudentCreateResponseDto> createStudent(@RequestBody@Valid StudentCreateRequestDto studentCreateRequestDto) {
        return new ResponseEntity<>(studentService.createStudent(studentCreateRequestDto), HttpStatus.CREATED);
    }
    @GetMapping( "/api/v1/students/{studentId}/receipts")
    public ResponseEntity<StudentCreateResponseDto> viewReceipts(@PathVariable long studentId) {
        return new ResponseEntity<>(studentService.viewReceipts(studentId), HttpStatus.CREATED);
    }
}
