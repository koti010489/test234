package com.student.management.dto;

import java.util.List;

public class ViewReceiptsResponseDto {
    private String name;
    private String grade;
    private String schoolName;
    private String reference;
    private String cardNo;
    private String cardType;
    private long studentId;
    private List<PaymentDetailsDto> paymentDetailsDtoList;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public List<PaymentDetailsDto> getPaymentDetailsDtoList() {
        return paymentDetailsDtoList;
    }

    public void setPaymentDetailsDtoList(List<PaymentDetailsDto> paymentDetailsDtoList) {
        this.paymentDetailsDtoList = paymentDetailsDtoList;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }
}
