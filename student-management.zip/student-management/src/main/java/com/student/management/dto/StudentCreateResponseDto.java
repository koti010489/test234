package com.student.management.dto;

import com.student.management.entity.StudentEntity;
import com.student.management.exception.ErrorDto;

import java.util.List;

public class StudentCreateResponseDto{
    private StudentEntity studentData;

    private List<ErrorDto> errors;

    public StudentEntity getStudentData() {
        return studentData;
    }

    public void setStudentData(StudentEntity studentData) {
        this.studentData = studentData;
    }

    public List<ErrorDto> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorDto> errors) {
        this.errors = errors;
    }
}
