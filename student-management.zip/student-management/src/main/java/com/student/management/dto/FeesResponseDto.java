package com.student.management.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public class FeesResponseDto {
    private LocalDateTime transactionTime;
    private String reference;
    private long studentId;
    private String name;
    private String grade;
    private String schoolName;

    private List<PaymentDetailsDto> paymentDetailsDtoList;
    private BigDecimal totalAmount;

    public LocalDateTime getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(LocalDateTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public List<PaymentDetailsDto> getPaymentDetailsDtoList() {
        return paymentDetailsDtoList;
    }

    public void setPaymentDetailsDtoList(List<PaymentDetailsDto> paymentDetailsDtoList) {
        this.paymentDetailsDtoList = paymentDetailsDtoList;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}


