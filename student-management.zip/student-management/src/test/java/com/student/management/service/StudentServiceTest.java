package com.student.management.service;

import com.student.management.dto.StudentCreateRequestDto;
import com.student.management.dto.StudentCreateResponseDto;
import com.student.management.entity.StudentEntity;
import com.student.management.exception.StudentCreationException;
import com.student.management.repositry.StudentRepository;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class StudentServiceTest {
    @InjectMocks
    StudentService studentService;
    @Mock
    StudentRepository studentRepository;

    @Test
    public void testCreateStudent(){
        StudentCreateRequestDto studentCreateRequestDto = new StudentCreateRequestDto();
        StudentEntity studentEntity = new StudentEntity();

        when(studentRepository.save(any())).thenReturn(studentEntity);

        StudentCreateResponseDto studentCreateResponseDto = studentService.createStudent(studentCreateRequestDto);

        Assertions.assertEquals(studentCreateResponseDto.getStudentData(), studentEntity);

    }

    @Test
    public void testCreateStudent_Exception(){
        StudentCreateRequestDto studentCreateRequestDto = new StudentCreateRequestDto();
        RuntimeException exception = new RuntimeException("Exception occurred while processing message");

        when(studentRepository.save(any())).thenThrow(exception);

        Assertions.assertThrows(StudentCreationException.class, ()-> studentService.createStudent(studentCreateRequestDto));



    }
}
