package com.student.management.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.student.management.dto.StudentCreateResponseDto;
import com.student.management.entity.StudentEntity;
import com.student.management.exception.ErrorDto;
import com.student.management.exception.StudentCreationException;
import com.student.management.service.StudentService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(StudentController.class)
public class StudentControllerTest {
    private static  final Logger LOGGER = LoggerFactory.getLogger(StudentController.class);;
    @Autowired
    MockMvc mockMvc;

    @MockBean
    StudentService studentService;

    @Test
    public void testValidStudent() throws Exception {
        String json = """
                {
                "name" :"StudentName",
                "grade" :"10",
                "schoolName":"TestSchool",
                "mobileNumber":"7845044646"

                }""";

        StudentCreateResponseDto studentCreateResponseDto = new StudentCreateResponseDto();
        StudentEntity studentEntity = readObject(json,new StudentEntity());
        studentCreateResponseDto.setStudentData(studentEntity);
        when(studentService.createStudent(any())).thenReturn(studentCreateResponseDto);



        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/students").content(json).
                        accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)).
                andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(jsonPath("$.studentData.name", is("StudentName")))
                .andExpect(jsonPath("$.studentData.grade", is("10")))
                .andExpect(jsonPath("$.studentData.mobileNumber", is("7845044646")))
        ;

    }

    @Test
    public void testStudentName_Null() throws Exception {
        String json = """
                {
               
                "grade" :"10",
                "schoolName":"TestSchool",
                "mobileNumber":"7845044646"

                }""";
        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/students").content(json).
                        accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)).
                andExpect(MockMvcResultMatchers.status().isBadRequest());

    }

    @Test
    public void testStudentCreation_Exception() throws Exception {
        String json = """
                {
                "name" :"StudentName",
                "grade" :"10",
                "schoolName":"TestSchool",
                "mobileNumber":"7845044646"

                }""";
        String errorMessage ="Exception occurred while creating student";

        StudentCreateResponseDto studentCreateResponseDto = new StudentCreateResponseDto();
        ErrorDto errorDto = new ErrorDto(errorMessage);
        StudentEntity studentEntity = readObject(json,new StudentEntity());
        studentCreateResponseDto.setStudentData(studentEntity);

        when(studentService.createStudent(any())).thenThrow(new StudentCreationException(errorDto));



        mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/students").content(json).
                        accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)).
                andExpect(MockMvcResultMatchers.status().isInternalServerError())
                .andExpect(jsonPath("$.errors",hasSize(1)))

        ;

    }
    private <T> T readObject(String jsonString,T t)  {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            t = (T) objectMapper.readValue(jsonString,t.getClass());
        } catch (JsonProcessingException e) {
            LOGGER.error("Exception occurred while un marshaling json string {}",e.getMessage());
        }
        return t;
    }
}
