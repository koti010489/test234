package com.fees.management.service;

import com.fees.management.dto.FeesRequestDto;
import com.fees.management.dto.FeesResponseDto;
import com.fees.management.entity.FeesMaster;
import com.fees.management.entity.PaymentDetails;
import com.fees.management.entity.StudentFeeMapping;
import com.fees.management.repositry.FeesMasterRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FeesSerivce {
    @Autowired FeesMasterRepository feesMasterRepository;
    public FeesResponseDto createFeeDetails(FeesRequestDto feesRequestDto) {
        FeesResponseDto feesResponseDto = new FeesResponseDto();
        LocalTime currentTime = LocalTime.now();
        long studentId = feesRequestDto.getStudentId();
        feesResponseDto.setRequest(feesRequestDto);
        FeesMaster feesMaster = new FeesMaster();
        BeanUtils.copyProperties(feesRequestDto, feesMaster);
        feesMaster.setTransactionTime(currentTime);
        if (!CollectionUtils.isEmpty(feesRequestDto.getPaymentDetailsDtoList())) {
            feesMaster.setPaymentDetailsList(feesRequestDto.getPaymentDetailsDtoList().stream().
                    map(paymentDetailsDto -> {
                        PaymentDetails paymentDetails = new PaymentDetails();
                        BeanUtils.copyProperties(paymentDetailsDto, paymentDetails);
                        paymentDetails.setFeesMaster(feesMaster);
                        return paymentDetails;
                    }).collect(Collectors.toList()));
            feesMaster.setTotalAmount(feesRequestDto.getPaymentDetailsDtoList().stream().
                    map(paymentDetailsDto -> paymentDetailsDto.getAmount()).reduce(new BigDecimal(0), BigDecimal::add));
        }
        StudentFeeMapping studentFeeMapping = new StudentFeeMapping();
        studentFeeMapping.setFeesMaster(feesMaster);
        studentFeeMapping.setStudentId(studentId);
        feesMaster.setStudentFeeMappingList(List.of(studentFeeMapping));
        feesMasterRepository.save(feesMaster);

        feesResponseDto.setRequest(feesRequestDto);
        feesResponseDto.setReference(feesMaster.getReferenceNumber().toString());
        feesResponseDto.setTransactionTime(currentTime);
        feesResponseDto.setTotalAmount(feesMaster.getTotalAmount());
        return feesResponseDto;
    }
}
