package com.fees.management.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.math.BigDecimal;
@Entity
public class PaymentDetails {
    @Id

    private String purchaseItemName;
    private String currency;
    private BigDecimal amount;
    @ManyToOne
    @JoinColumn(name="referenceNumber", nullable=false)
    private FeesMaster feesMaster;

    public String getPurchaseItemName() {
        return purchaseItemName;
    }

    public void setPurchaseItemName(String purchaseItemName) {
        this.purchaseItemName = purchaseItemName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public FeesMaster getFeesMaster() {
        return feesMaster;
    }

    public void setFeesMaster(FeesMaster feesMaster) {
        this.feesMaster = feesMaster;
    }
}
