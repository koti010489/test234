package com.fees.management.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class FeesRequestDto {

    private String modeOfPayment;
    private String cardType;
    private String cardNumber;

    private long studentId;
    private List<PaymentDetailsDto> paymentDetailsDtoList;



    public String getModeOfPayment() {
        return modeOfPayment;
    }

    public void setModeOfPayment(String modeOfPayment) {
        this.modeOfPayment = modeOfPayment;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public List<PaymentDetailsDto> getPaymentDetailsDtoList() {
        return paymentDetailsDtoList;
    }

    public void setPaymentDetailsDtoList(List<PaymentDetailsDto> paymentDetailsDtoList) {
        this.paymentDetailsDtoList = paymentDetailsDtoList;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }


}
