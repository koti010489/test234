package com.fees.management.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
@Entity
public class FeesMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID referenceNumber;
    private String modeOfPayment;
    private String cardType;
    private String cardNumber;
    private LocalTime transactionTime;
    @OneToMany(mappedBy="feesMaster")
    private List<PaymentDetails> paymentDetailsList;

    @OneToMany(mappedBy="feesMaster")
    private List<StudentFeeMapping> studentFeeMappingList;

    private BigDecimal totalAmount;

    public UUID getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(UUID referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getModeOfPayment() {
        return modeOfPayment;
    }

    public void setModeOfPayment(String modeOfPayment) {
        this.modeOfPayment = modeOfPayment;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public List<PaymentDetails> getPaymentDetailsList() {
        return paymentDetailsList;
    }

    public void setPaymentDetailsList(List<PaymentDetails> paymentDetailsList) {
        this.paymentDetailsList = paymentDetailsList;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public LocalTime getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(LocalTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    public List<StudentFeeMapping> getStudentFeeMappingList() {
        return studentFeeMappingList;
    }

    public void setStudentFeeMappingList(List<StudentFeeMapping> studentFeeMappingList) {
        this.studentFeeMappingList = studentFeeMappingList;
    }
}
