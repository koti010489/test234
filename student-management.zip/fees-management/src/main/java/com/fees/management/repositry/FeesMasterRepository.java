package com.fees.management.repositry;

import com.fees.management.entity.FeesMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface FeesMasterRepository extends JpaRepository<FeesMaster, UUID> {
}
