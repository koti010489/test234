package com.fees.management.entity;

import jakarta.persistence.*;

@Entity
public class StudentFeeMapping {
    @Id
    @GeneratedValue
    private long id;

    private long studentId;

    @ManyToOne
    @JoinColumn(name="referenceNumber", nullable=false)
    private FeesMaster feesMaster;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public FeesMaster getFeesMaster() {
        return feesMaster;
    }

    public void setFeesMaster(FeesMaster feesMaster) {
        this.feesMaster = feesMaster;
    }
}
