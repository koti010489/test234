package com.fees.management.dto;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.List;

public class FeesResponseDto {
    private LocalTime transactionTime;
    private String reference;

    private FeesRequestDto request;
    private BigDecimal totalAmount;

    public LocalTime getTransactionTime() {
        return transactionTime;
    }

    public void setTransactionTime(LocalTime transactionTime) {
        this.transactionTime = transactionTime;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public FeesRequestDto getRequest() {
        return request;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public void setRequest(FeesRequestDto request) {
        this.request = request;
    }
}
