package com.fees.management.controller;

import com.fees.management.dto.FeesRequestDto;
import com.fees.management.dto.FeesResponseDto;
import com.fees.management.service.FeesSerivce;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeesController {
    @Autowired
    private FeesSerivce feesSerivce;

    @PostMapping("/api/v1/fees")
    public ResponseEntity<FeesResponseDto> createFeeDetails(@RequestBody @Valid FeesRequestDto feesRequestDto) {
        return new ResponseEntity<>(feesSerivce.createFeeDetails(feesRequestDto), HttpStatus.CREATED);

    }
}
